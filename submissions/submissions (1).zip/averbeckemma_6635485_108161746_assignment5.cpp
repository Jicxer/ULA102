#include <iostream>
#include <cmath>
using namespace std;

float calc_circle_area(float rad){
    return pow(rad, 2)*3.14159265;
}

float calc_max_power(float area, float speed){
    float calc = 0.5*1.2*area*pow(speed, 3);
    return calc/1000;
}

float calc_actual_power(float mxpwr, float percent){
    float pcnt = percent / 100;
    return mxpwr * pcnt;
}

int main(){
    float wind_speed;
    cout << "Enter the average wind speed in m/s: ";
    cin >> wind_speed;
    float radius;
    cout << "Enter the radius of the turbine blades in m/s: ";
    cin >> radius;
    float percent_efficiency;
    cout << "Enter the percent operating efficiency: ";
    cin >> percent_efficiency;

    float turbine_area = calc_circle_area(radius);
    float max_power = calc_max_power(turbine_area, wind_speed);
    float actual_power = calc_actual_power(max_power, percent_efficiency);

    cout << "Area of turbine blades: " << turbine_area << endl;
    cout << "Maximum power of the wind turbine: " << max_power << endl;
    cout << "Actual power of the wind turbine: " << actual_power << endl;

    return 0;
}