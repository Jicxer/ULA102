def calc_circle_area(rad):
    return pow(rad, 2)*3.14159265;

def calc_max_power(area, speed):
    calc = 0.5*1.2*area*pow(speed, 3)
    return calc/1000;

def calc_actual_power(maxpwr, percent):
    pcnt = percent / 100;
    return maxpwr * pcnt;


wind_speed = float(input("Enter the average wind speed in m/s: "));
radius = float(input("Enter the radius of the wind turbine blades in meters: "));
percent_efficiency = float(input("Enter the percent operating efficiency: "));
turbine_area = calc_circle_area(radius);
max_power = calc_max_power(turbine_area, wind_speed);
actual_power = calc_actual_power(max_power, percent_efficiency);

print("Area of turbine blades:", turbine_area);
print("Maximum power of the wind turbine:", max_power);
print("Actual power of the wind turbine:", actual_power);

