def circleArea(radius):
    return 3.14159265 * radius**2

def maxPower(windSpeed, bladeArea):
    return (0.5*1.2*bladeArea * (windSpeed * windSpeed * windSpeed)) / 1000

def actualPower(maxPower, operatingEfficiency):
    return maxPower * (operatingEfficiency / 100)

radius = float(input("Enter radius of the blades: "))
windSpeed = float(input("Enter wind speed: "))
operatingEfficiency = float(input("Enter operating efficiency %: "))

print(actualPower(maxPower(windSpeed, circleArea(radius)), operatingEfficiency))