#include <iostream>

float circleArea(float radius) {
    return radius * radius * 3.14159265;
}

float maxPower(float bladeArea, float windSpeed) {
    return (0.5 * 1.2 * bladeArea * windSpeed * windSpeed * windSpeed) / 1000;
}

float actualPower(float maxPower, float operatingEfficiency) {
    return maxPower * (operatingEfficiency / 100);
}

int main(int argc, char* argv[]) {
    float radius;
    float windSpeed;
    float operatingEfficiency;

    std::cout << "Enter radius of blades: ";
    std::cin >> radius;
    std::cout << "Enter wind speed: ";
    std::cin >> windSpeed;
    std::cout << "Enter operating efficiency %: ";
    std::cin >> operatingEfficiency;

    std::cout << "The power output of the described turbine is: " << actualPower(maxPower(circleArea(radius), windSpeed), operatingEfficiency) << std::endl;
}