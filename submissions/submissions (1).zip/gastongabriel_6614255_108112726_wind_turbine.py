import math #So the value of pi can be used to increase accuracy

#Function uses the value of pi from the math module along with a user-specified radius to calculate the area of a circle
def calc_area_of_circle(radius):
    return math.pi*radius**2

#Function uses the area of the circle previously calculated and the user-specified average wind speed to calculate the maximum power output if the wind turbine was 100% efficient
def calc_max_power(area, average_wind_speed):
    return 0.6*area*average_wind_speed**3

#Function uses the maximum power and the user-specified operating efficiency to calculate the actual expected power output of the wind turbine
def calc_actual_power(max_power, operating_efficiency):
    return max_power * operating_efficiency

#Initialzing variables to 'None' so the while loop can work with the try-except statements to make the user enter a valid input
radius = None
average_wind_speed = None
operating_efficiency = None

#Getting user input for the radius
while(radius is None):
    try:
        radius = float(input("What is the radius of the blades on your wind turbine in meters?"))
    except:
        print("You must enter a numerical value.")

#Getting user input for the average wind speed
while(average_wind_speed is None):
    try:
        average_wind_speed = float(input("What is the average wind speed in m/s?"))
    except:
        print("You must enter a numerical value.")

#Getting user input for the operating efficiency
while(operating_efficiency is None):
    try:
        operating_efficiency = float(input("What is the operating effiency of your wind turbine in %?"))
        #Makes sure user doesn't enter operating efficiencies above 100%
        if(operating_efficiency > 100): 
            operating_efficiency = None
            print("You cannot enter an operating efficiency above 100%.")
        #In case the user inters a whole number this will make it decimal
        elif(operating_efficiency > 1):
            operating_efficiency = operating_efficiency /100
    except:
        print("You must enter a numerical value.")

#Calling functions to calculate values
area = calc_area_of_circle(radius)
max_power = calc_max_power(area, average_wind_speed)
actual_power = calc_actual_power(max_power, operating_efficiency)

#Formats the variables so they only have four decimal places
area = "{:.4f}".format(area)
max_power = "{:.4f}".format(max_power)
actual_power = "{:.4f}".format(actual_power)

#Printing values for the user
print("\n\nThe area of your wind turbine is:", area, "m\u00b2." #Some unicode for superscript
      "\nThe maximum power output of your wind turbine is:", max_power, "kWh."
      "\nThe actual power output of your wind turbine is:", actual_power, "kWh.")