#include <iostream>
using namespace std;

void Print(string output);
float GetFloat(string message);
float AreaOfCircle(float radius);
float MaximumPower(float pressure, float area, float speed);
float ActualPower(float max, float efficiency);

int main()
{
    float windSpeed = GetFloat("What is the average wind speed in m/s?");
    float bladeRadius = GetFloat("What is the radius of the turbine blades in meters?");
    float efficiency = GetFloat("What is the operating efficiency as a percentage? (0-100)") * 0.01;

    if (windSpeed < 0 || bladeRadius < 0)
    {
        Print("ERROR: Values cannot be less than 0!");
        return 0;
    }

    if (efficiency < 0 || efficiency > 1)
    {
        Print("ERROR: Operating efficiency must be a value between 0 and 100!");
        return 0;
    }

    float area = AreaOfCircle(bladeRadius);
    float maxPower = MaximumPower(1.2, area, windSpeed);
    float actualPower = ActualPower(maxPower, efficiency);

    Print("The area is " + to_string(area) + " square meters.");
    Print("The maximum power is " + to_string(maxPower) + " kilowatts.");
    Print("The actual power is " + to_string(actualPower) + " kilowatts.");
}

void Print(string output)
{
    cout << output << endl;
}

float GetFloat(string message)
{
    Print(message);
    
    float input;
    cin >> input;
    return input;
}

float AreaOfCircle(float radius)
{
    return (radius * radius) * 3.14159265358979;
}

float MaximumPower(float pressure, float area, float speed)
{
    return 0.5 * pressure * area * (speed * speed * speed) * .001;
}

float ActualPower(float max, float efficiency)
{
    return max * efficiency;
}