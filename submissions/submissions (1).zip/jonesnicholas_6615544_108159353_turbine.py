def Print(output):
    print(output)

def GetFloat(message):
    inp = float(input(message))
    return(inp)

def AreaOfCircle(radius):
    return (radius * radius) * 3.14159265358979

def MaximumPower(pressure, area, speed):
    return 0.5 * pressure * area * (speed * speed * speed) * .001

def ActualPower(max, efficiency):
    return max * efficiency


#MAIN CODE
windSpeed = GetFloat("What is the average wind speed in m/s? ")
bladeRadius = GetFloat("What is the radius of the turbine blades in meters? ")
efficiency = GetFloat("What is the operating efficiency as a percentage? (0-100) ") * 0.01

if (windSpeed < 0 or bladeRadius < 0):
    Print("ERROR: Values cannot be less than 0!")
    exit()

if (efficiency < 0 or efficiency > 1):
    Print("ERROR: Operating efficiency must be a value between 0 and 100!")
    exit()

area = AreaOfCircle(bladeRadius)
maxPower = MaximumPower(1.2, area, windSpeed)
actualPower = ActualPower(maxPower, efficiency)

Print("The area is " + str(area) + " square meters.")
Print("The maximum power is " + str(maxPower) + " kilowatts.")
Print("The actual power is " + str(actualPower) + " kilowatts.")