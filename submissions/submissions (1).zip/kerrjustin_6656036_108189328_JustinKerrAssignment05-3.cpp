#include <iostream>
#include <limits>
#include <string>
#include <type_traits>
#include <cmath>

using namespace std;

double calculate_cross_sectional_area(double bladeradius) {
    //equation to calculate the area given the blade radius in meters
    //output is in m^2
    return (M_PI)*(pow(bladeradius, 2));
}

double calculate_max_power(double area,double velocity) {
    //equation to calculate the maximum power output of the turbine
    //output is in kW
    double ro=1.2; //kg per m^3
    double A=area; //m^2
    double v=velocity; //m per s
    return ((0.5)*ro*A*(pow(v, 3)))/1000;
}

double calculate_actual_power(double P_max, double efficiency) {
    //equation to calculate actual power output of the turbine
    return P_max*(efficiency/100);
}

int main() {
    double bladeradius;
    double area;
    double velocity;
    double P_max;
    double efficiency;
    double actual_power;

    while (true) {
        cout << "Please enter the blade radius [m]: "; 
        if (!(cin>>bladeradius)) {
            cin.clear(); 
            string input;
            cin>>input; 
            if (input=="true"||input=="false") {
                cout<<"You cannot enter a boolean. Please try again. "<<endl;
            } else {
                cout<<"You cannot enter text. Please try again. "<<endl;
            }
        } 
        else if (bladeradius<0) {
            cout<<"You cannot have a negative blade radius. Please try again. "<<endl;
        } 
        else {
            break;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    while (true) {
        cout << "Please enter the wind speed [m/s]: "; 
        if (!(cin>>velocity)) {
            cin.clear(); 
            string input;
            cin>>input; 
            if (input=="true"||input=="false") {
                cout<<"You cannot enter a boolean. Please try again. "<<endl;
            } else {
                cout<<"You cannot enter text. Please try again. "<<endl;
            }
        } 
        else if (velocity<0) {
            cout<<"You cannot have a negative wind speed. Please try again. "<<endl;
        } 
        else {
            break;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    while (true) {
        cout << "Please enter the turbine efficiency [%]: "; 
        if (!(cin>>efficiency)) {
            cin.clear(); 
            string input;
            cin>>input; 
            if (input=="true"||input=="false") {
                cout<<"You cannot enter a boolean. Please try again. "<<endl;
            } else {
                cout<<"You cannot enter text. Please try again. "<<endl;
            }
        } 
        else if (efficiency<0) {
            cout<<"You cannot have a efficiency. Please try again. "<<endl;
        } 
        else {
            break;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    area=calculate_cross_sectional_area(bladeradius);
    P_max=calculate_max_power(area,velocity);
    actual_power=calculate_actual_power(P_max,efficiency);

    cout<<"This is the maximum power output [kW]: "<<endl;
    cout<<P_max<<endl;
    cout<<"This is the actual power output [kW]: "<<endl;
    cout<<actual_power<<endl;

    return 0;
}
