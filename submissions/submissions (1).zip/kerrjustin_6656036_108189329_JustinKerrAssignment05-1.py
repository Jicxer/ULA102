import math;

def calculate_cross_sectional_area(BladeRadius:float)->float:
    #equation to calculate the area of a circle [m^2]
    return (math.pi)*(BladeRadius**2);

def calculate_max_power(area,velocity:float)->float:
    #equation to calculate the maximum power available [kW]
    ro=1.2 #kg/m^3
    A=area #m^2
    v=velocity
    return ((0.5)*ro*A*(v**3))/1000;

def calculate_actual_power(P_Max,efficiency:float)->float:
    #equation to calculate actual power output [kW]
    return P_Max*(efficiency/100);

while True:
    try:
        BladeRadius=input("Please enter the blade radius [m]: ")
        BladeRadius=float(BladeRadius)
        if BladeRadius>=0:
            break
        elif BladeRadius<0:
            print("You cannot have a negative blade radius. Please try again.")
    except ValueError:
        if BladeRadius.lower() == True or BladeRadius.lower() == False:
            print("You cannot have a Boolean. Please Try again.")
        else:
            print("You cannot enter text. Please try again.");

while True:
    try:
        velocity=input("Please enter the wind speed [m/s]: ")
        velocity=float(velocity)
        if velocity>=0:
            break
        elif velocity<0:
            print("You cannot have a negative wind speed. Please try again.")
    except ValueError:
        if velocity.lower() == True or velocity.lower() == False:
            print("You cannot have a Boolean. Please Try again.")
        else:
            print("You cannot enter text. Please try again.");

while True:
    try:
        efficiency=input("Please enter the turbine efficiency [%]: ")
        efficiency=float(efficiency)
        if efficiency>=0:
            break
        elif efficiency<0:
            print("You cannot have a negative turbine efficiency. Please try again.")
    except ValueError:
        if efficiency.lower() == True or efficiency.lower() == False:
            print("You cannot have a Boolean. Please Try again.")
        else:
            print("You cannot enter text. Please try again.");

area=calculate_cross_sectional_area(BladeRadius);
P_Max=calculate_max_power(area,velocity);
actual_power=calculate_actual_power(P_Max,efficiency);

print("The maximum power output is:");
print(round(P_Max,2),"kW")
print("The actual power output is:")
print(round(actual_power,2),"kW");