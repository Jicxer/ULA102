#define _USE_MATH_DEFINES
#include <iostream>
#include <tuple>
#include <limits>
#include <math.h>
using namespace std;

tuple<float, float, float> getInput() {
    float radius, speed, efficiency;
    int goodInput = 0;

    while(true) {
        if (goodInput == 0) {
            cout << "Radius: ";
            cin >> radius;
            if(!cin.good()) {
                cout << "Error: radius must be a number" << endl;
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else if(radius < 0) {
                cout << "Error radius must be positive" << endl;
            }
            else {
                goodInput++;
            }
        }

        if (goodInput == 1) {
            cout << "Speed: ";
            cin >> speed;
            if(!cin.good()) {
                cout << "Error: speed must be a number" << endl;
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else if(speed < 0) {
                cout << "Error speed must be positive" << endl;
            }
            else {
                goodInput++;
            }
        }

        if(goodInput == 2){
            cout << "Efficiency: ";
            cin >> efficiency;
            if(!cin.good()) {
                cout << "Error: efficiency must be a number" << endl;
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
            else if(efficiency < 0 || efficiency > 100) {
                cout << "Error efficiency must be 0-100" << endl;
            }
            else {
                break;
            }
        }
    }

    return make_tuple(radius, speed, efficiency);
}
float getArea(float radius) {
    float area;
    area = M_PI * pow(radius, 2);
    return area;
}
float getPowerMax(float area, float speed) {
    float powerMax;
    powerMax = 0.0006 * area * pow(speed, 3);
    return powerMax;
}
float getPowerAct(float powerMax, float efficiency) {
    float powerAct;
    powerAct = efficiency / 100 * powerMax; 
    return powerAct;
}

int main() {
    //tie unpacks tuple
    float radius, speed, efficiency, 
          area, powerMax, powerAct;
    tie(radius, speed, efficiency) = getInput();
    area = getArea(radius);
    powerMax = getPowerMax(area, speed);
    powerAct = getPowerAct(powerMax, efficiency);
    cout << "Maximum power (kW): " << round(powerMax * 100) / 100 << endl
         << "Actual power (kW): " << round(powerAct * 100) / 100;
}
