import math

def getInput():
    goodInput = 0
    while True:
        try:
            if goodInput == 0:
                radius = float(input("Radius: "))
                if radius < 0:
                    print("Error radius must be non-negative")
                    continue
                goodInput += 1

            if goodInput == 1:
                speed = float(input("Speed: "))
                if speed < 0:
                    print("Error speed must be non-negative")
                    continue
                goodInput += 1

            efficiency = float(input("Efficiency: "))
            if efficiency < 0 or efficiency > 100:
                print("Error efficiency must be 0-100")
                continue
            break
        except:
            if goodInput == 0:
                print("Error: radius must be a number")
            if goodInput == 1:
                print("Error: speed must be a number")
            if goodInput == 2:
                print("Error: efficiency must be a number")
    return radius, speed, efficiency
def getArea(radius):
    area = math.pi * (radius ** 2)
    return area
def getPowerMax(area, speed):
    powerMax = 0.0006 * area * (speed ** 3)
    return powerMax
def getPowerAct(powerMax, efficiency):
    powerAct = efficiency / 100 * powerMax
    return powerAct

radius, speed, efficiency = getInput()
area = getArea(radius)
powerMax = getPowerMax(area, speed)
powerAct = getPowerAct(powerMax, efficiency)
print(f'Maximum power (kW): {round(powerMax, 2)}')
print(f'Actual power (kW): {round(powerAct, 2)}')

