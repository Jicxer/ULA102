import math

def area(radius):
    return math.pi * radius**2

def max_power(area, speed):
    p=1.2
    return 0.5*p*area*speed**3

def actual_power(power, efficiency):
    return power*efficiency

def print_power(radius,speed,efficiency):
    act_power = actual_power(max_power(area(radius), speed), efficiency)
    print("Power with radius " + str(radius) + ", speed of " + str(speed) + ", efficiency of " + str(efficiency) + ", is: " + str(act_power/1000)[:6] + "kW")

print_power(25.8, 8.5, 0.21)