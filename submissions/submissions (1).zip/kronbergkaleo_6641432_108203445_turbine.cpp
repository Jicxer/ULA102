#include <iostream>
#include <math.h>

using namespace std;

float circ_area (float radius) {
    float area;
    area = pow(radius, 2) * M_PI;
    return area;
}

float max_power(float area, float speed) {
    float p = 1.2;
    float power;
    power = 0.5*area*p*pow(speed, 3);
    return power;
}

float actual_power(float power, float efficiency) {
    float act_power;
    act_power = power * efficiency;
    return act_power;
}

int print_power(float radius, float speed, float efficiency) {
    float act_power = actual_power(max_power(circ_area(radius), speed), efficiency);
    cout << "Power generated with radius of " << radius << ", speed of " << speed << ", efficiency of " << efficiency << " is " << act_power/1000 << "kW" <<endl; 
    return 0;
}

int main() {
    print_power(25.8, 8.5, 0.21);
    return 0;
}