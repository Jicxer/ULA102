

#include <iostream>
#include <cmath>

using namespace std;


float calc_blade_circle_area(float blade_radius) {
    return 3.14159265 * pow(blade_radius, 2);
}

float calc_max_power(float blade_circle_area, float wind_speed) {
    return (0.5 * 1.2 * blade_circle_area * pow(wind_speed, 3)) / 1000; // 1.2 = air density
}

float calc_actual_power(float max_power, float operating_efficiency) {
    return max_power * (operating_efficiency / 100);
}


int main() {

    float blade_radius;
    cout << "Enter the blade radius of the wind turbine in meters: ";
    cin >> blade_radius;

    float wind_speed;
    cout << "Enter the wind speed in meters per second: ";
    cin >> wind_speed;

    float operating_efficiency;
    cout << "Enter the operating efficiency of the wind turbine (Must be written without the %. Example: 5% = 5): ";
    cin >> operating_efficiency;


    float blade_circle_area = calc_blade_circle_area(blade_radius);
    float max_power = calc_max_power(blade_circle_area, wind_speed);
    float actual_power = calc_actual_power(max_power, operating_efficiency);

    cout << "This is the cross-sectional area of the blades: " << blade_circle_area << endl;
    cout << "This is the maximum power of the wind turbine: " << max_power << endl;
    cout << "This is the actual power of the wind turbine: " << actual_power << endl;

    return 0;
}