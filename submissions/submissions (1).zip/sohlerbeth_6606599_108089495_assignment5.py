

def calc_blade_circle_area(blade_radius):
    return 3.14159265 * pow(blade_radius, 2);

def calc_max_power(blade_circle_area, wind_speed):
    return (0.5 * 1.2 * blade_circle_area * pow(wind_speed, 3)) / 1000; # 1.2 = air density

def calc_actual_power(max_power, operating_efficiency):
    return max_power * (operating_efficiency / 100);


print("Enter the blade radius of the wind turbine in meters: ");
blade_radius = float(input());

print("Enter the wind speed in meters per second: ");
wind_speed = float(input());

print("Enter the operating efficiency of the wind turbine (Must be written without the %. Example: 5% = 5): ");
operating_efficiency = float(input());


blade_circle_area = calc_blade_circle_area(blade_radius);
max_power = calc_max_power(blade_circle_area, wind_speed);
actual_power = calc_actual_power(max_power, operating_efficiency);

print("This is the cross-sectional area of the blades: ", blade_circle_area);
print("This is the maximum power of the wind turbine: ", max_power);
print("This is the actual power of the wind turbine: ", actual_power);