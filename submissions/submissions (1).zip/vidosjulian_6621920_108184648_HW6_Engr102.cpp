#include <iostream>
using namespace std;


//get input checks the user input must have no characters and not be negative  
float getInput(){
    float in;
    bool valid = false;
    //ask user for input until a valid input is given
    while(!(valid)){
        cin >> in;
        if(cin.fail()){
            //clears the error
            cin.clear();
            //discards the line (for up to 1000 character or next new line)
            cin.ignore(1000, '\n');
            cout << "Invalid input! You must input a number try again: ";
        }else if(in < 0){
            cout << "Invalid input! No negative numbers try again: ";
        }else{
            //if number and characters input ignores character allowing inputs like 8.5mph (for up to 1000 character or next line) 
            cin.ignore(123, '\n');
            valid = true;
        }
    }
    return in;
}

//get wind speed from user
float getWindSpeed(){
    cout << "What is the wind speed: ";
    float ws = getInput();
    return ws;
}

//get radius of blade 
float getRadius(){
    cout << "What is the length of the fan blades: ";
    float r = getInput(); 
    return r;
}

//get eff of turbine
float getEff(){
    cout << "What is the efficiency of the turbine: ";
    float eff = getInput();
    return eff/100.0;
}

//calculate Area A=pir^2
float calculateArea(float radius){
    float A = 3.14159265*radius*radius;
    return A;
}

//calculate Max Power (0.5pAv^3)/(1000)
float calculateMaxPower(float area, float windSpeed){
    float P = (.5*1.2*area*windSpeed*windSpeed*windSpeed)/1000.0;
    return P;
}

float calculateActualPower(float power, float eff){
    return power*eff;
}

int main(){
    //set wind speed, radius, and efficiency then print 
    float windSpeed = getWindSpeed();
    float radius = getRadius();
    float efficiency = getEff(); 
    cout << "The wind speed " << windSpeed << endl;
    cout << "The radius " << radius << endl;
    cout << "The efficiency " << efficiency << endl;

    //get area, max power, and actual power then print 
    float area = calculateArea(radius);
    float maxPower = calculateMaxPower(area, windSpeed);
    float actualPower = calculateActualPower(maxPower, efficiency);
    cout << "The area is " << area << endl;
    cout << "The max power is " << maxPower << endl;
    cout << "The actual power is " << actualPower << endl;

    return 0;
}