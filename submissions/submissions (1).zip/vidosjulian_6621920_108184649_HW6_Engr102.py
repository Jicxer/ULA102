import math;

def getInput()-> float:
    valid: bool = False;
    while(valid == False):
        try:
            num: float = float(input());
        except ValueError:
            print("Invalid input! You must enter a number try again: ");
        else:
            if(num < 0):
                print("Invalid input! No negative numbers try again: ");
                valid = False;
            else:
                valid = True;

    return num;

#get wind speed 
def getWindSpeed()-> float:
    print("What is the wind speed: ");
    ws: float = getInput();
    return ws;

#get radius 
def getRadius()-> float:
    print("What is the blade length: ");
    r: float = getInput();
    return r;

#get efficiency 
def getEff()-> float: 
    print("What is the Efficiency: ");
    eff: float = getInput();
    return eff/100;

#calculate area
def calcArea(radius: float)-> float:
    A: float = math.pi*pow(radius, 2);
    return A;

#calculate max power 
def calcMaxPower(windSpeed: float, area: float)-> float:
    P: float = (.5*1.2*area*pow(windSpeed, 3))/1000;
    return P;

#calculate actual power
def calcActualPower(power: float, eff: float)-> float:
    return power*eff;

#set wind speed, radius, and efficiency then print 
windSpeed: float = getWindSpeed();
radius: float = getRadius();
efficiency: float = getEff();
print("The wind speed is", windSpeed);
print("The Radius is", radius);
print("The efficiency is", efficiency);
#get area, max power, and actual power then print 
area: float = calcArea(radius);
maxPower: float = calcMaxPower(windSpeed, area);
actualPower: float = calcActualPower(maxPower, efficiency);
print("The area is", area);
print("The max power is", maxPower);
print("The actual power is ", actualPower);